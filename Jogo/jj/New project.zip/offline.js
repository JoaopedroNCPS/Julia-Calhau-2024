﻿{
	"version": 1724266614,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"tilemap.png",
		"per-sheet0.png",
		"per-sheet1.png",
		"morango-sheet0.png",
		"morango-sheet1.png",
		"morango-sheet2.png",
		"sprite-sheet0.png",
		"s-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"pathfind.js"
	]
}